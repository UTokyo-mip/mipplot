library(testthat)
library(mipplot)

test_check("mipplot")
