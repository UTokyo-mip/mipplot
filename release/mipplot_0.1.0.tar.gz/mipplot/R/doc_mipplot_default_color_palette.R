#' Default color palette.
#'
#' A default color palette object,
#' which maps variable name (such as "Land Use")
#' to hex color code.
#'
"mipplot_default_color_palette"
