#' mipplot
#'
#' Package contains generic functions to produce area/bar/box/line plots of data following IAMC submission format.
#'
#' @name mipplot
#' @docType package
#' @import ggplot2 stringr reshape2 tidyr
#'
NULL
